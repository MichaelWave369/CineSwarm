#include <errno.h>
#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
int main(void){
  int fd=socket(AF_INET,SOCK_STREAM,0);
  if(fd<0 && errno==EPERM){ puts("C1.24_NETWORK_SYSCALL_BLOCKED:EPERM"); return 0; }
  if(fd>=0) close(fd);
  fprintf(stderr,"network syscall was not blocked as required (fd=%d errno=%d)\n",fd,errno);
  return 1;
}
